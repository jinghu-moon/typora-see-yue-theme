# readme

1. moon-green 主题以 [Vue](https://github.com/blinkfox/typora-vue-theme) 主题为框架，参考了网上诸多的教程和主题，制作出来。非常感谢他们的无私分享。
2. 如果你觉得二级标题编号在背景外面，比较丑，可以修改代码。
   1. 用代码1替换二级标题样式二。
   2. 解除代码2的注释。

```css
/* 代码1 —— code_snippet.css */
#write h2  {
    display: inline-block;
    font-weight: bold;
    /* background: #e07a5f; */
    color: #ffffff;
    padding: 0px 6px 0px;
    border-radius: 4px;
    background-image: linear-gradient(to bottom, #74c69d, #b7e4c7);
}

#write h2:after {
    display: inline-block;
    content: "";
    position: absolute;
    bottom: -10px;
    top: auto;
    background-image: linear-gradient(to right, #c1dfc4 0%, #deecdd 100%);
    left: 0;
    right: 0;
    height: 4px;
    width: 940px;
}

/* 代码2 —— moon-green.css */
#write h2,
#write h2::before {
    color: #fff;
    font-family: "HarmonyOS";
}
```

<span style="color:#b91919;font-weight:bolder">注意：</span>修改后，会出现问题，两个二级标题中间没有文字、空格，它们会合并到一行上去。如果有文字、空格，就不会合并。

3. 我也非常乐意，你在 moon-green 主体基础下，写一个自己的 typora 主题。对于可能会修改的部分，我也给了注释。你也可以参考这两个网站：
   [CSS - 学习 Web 开发 | MDN](https://developer.mozilla.org/zh-CN/docs/Learn/CSS)、
   [ HTML  - 学习 Web 开发 | MDN ](https://developer.mozilla.org/zh-CN/docs/Learn/HTML)

4. 此外，我还制作了两个封面模板。这样一来，笔记就有了封面。good。封面模板1适合字数较少的笔记名，封面模板2适合字数较多的笔记名。

**美化没有尽头。**😂

