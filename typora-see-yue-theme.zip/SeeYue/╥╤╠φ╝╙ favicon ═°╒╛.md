# 目录

[TOC]

# 生活类

## 1.1 购物

1. [淘宝网 - 淘！我喜欢 (taobao.com)](https://www.taobao.com/) 
2. [京东(JD.COM)-正品低价、品质保障、配送及时、轻松购物！](https://www.jd.com/) 
3. [天猫tmall.com--理想生活上天猫](https://www.tmall.com/) 
4. [拼多多 新电商开创者 (pinduoduo.com)](https://www.pinduoduo.com/) 
5. [苏宁易购(Suning.com)-家电家装成套购，专注服务省心购！](https://www.suning.com/) 
6. [当当网 (dangdang.com)](http://www.dangdang.com/) 
7. [亚马逊-网上购物商城：要网购, 就来Z.cn! (amazon.cn)](https://www.amazon.cn/) 
8. [唯品会（vip.com）-12.8特卖大会](https://www.vip.com/) 
9. [阿里1688](https://www.1688.com/) 
10. [喵喵折 - 聪明网购不被坑 (miaomiaozhe.com)](https://www.miaomiaozhe.com/) 
11. [什么值得买 | 科学消费 认真生活 (smzdm.com)](https://www.smzdm.com/) 
12. [网易严选 - 以严谨的态度，为中国消费者甄选天下优品 (163.com)](https://you.163.com/) 
13. [识货-运动潮流好物 精选正品好价 (shihuo.cn)](http://www.shihuo.cn) 
14. [小米有品 (xiaomiyoupin.com)](https://www.xiaomiyoupin.com/) 
15. [微店官网-微信开店用微店 (weidian.com)](https://www.weidian.com/?source=guanwang)　
16. [得物App-新一代潮流网购社区 (dewu.com)](https://www.dewu.com/) 
17. [数码荔枝 x 软件商店 - 专注于分享最新鲜优秀的正版软件 (lizhi.io)](https://store.lizhi.io/) 
18. [【孔夫子旧书网】网上买书：图书\_书籍\_古籍\_二手书，网上卖书：网上书店_古旧书拍卖，国内专业的古旧书交易平台 (kongfz.com)](https://www.kongfz.com/) 
19. [盒马官网 - 盒马，鲜·美·生活 (freshippo.com)](https://www.freshippo.com/) 
20. [转转_转转二手官方验，买卖二手不一样 (zhuanzhuan.com)](https://www.zhuanzhuan.com/) 
21. [【北京二手车_北京二手车交易市场】-瓜子二手车 (guazi.com)](https://www.guazi.com/) 
22. [真快乐-综合网购商城，正品低价、品质保障、快速送达、安心服务！ (gome.com.cn)](https://www.gome.com.cn/) 

## 1.2 影视

1. [爱奇艺-在线视频网站-海量正版高清视频在线观看 (iqiyi.com)](https://www.iqiyi.com/) 
2. [腾讯视频 - 中国领先的在线视频媒体平台,海量高清视频在线观看 (qq.com)](https://v.qq.com/) 
3. [优酷 - 你的热爱 正在热播 (youku.com)](https://www.youku.com/) 
4. [哔哩哔哩 (゜-゜)つロ 干杯~-bilibili](https://www.bilibili.com/) 
5. [YouTube](https://www.youtube.com/) 
6. [Netflix — 在线观看电影和电视节目](https://www.netflix.com/) 
7. [芒果TV-天生青春 (mgtv.com)](https://www.mgtv.com/) 
8. [AcFun弹幕视频网 - 认真你就输啦 (・ω・)ノ- ( ゜- ゜)つロ](https://www.acfun.cn/) 
9. [西瓜视频 - 高清免费在线视频 - 点亮对生活的好奇心 (ixigua.com)](https://www.ixigua.com/) 
10. [CCTV节目官网_央视网](https://tv.cctv.com/) 
11. [咪咕-让今天更有趣 (migu.cn)](https://www.migu.cn/index.html) 
12. [抖音-记录美好生活 (douyin.com)](https://www.douyin.com/) 
13. [精彩推荐-快手 (kuaishou.com)](https://www.kuaishou.com/) 
14. [新片场 - 发现全球优质视频与创作人，与百万创作人一起成长 (xinpianchang.com)](https://www.xinpianchang.com/) 
15. [土豆-召唤全球优秀短视频 (tudou.com)](https://www.tudou.com/) 
16. [腾讯微视·发现更有趣 (qq.com)](https://weishi.qq.com/) 
17. [央视频 - 有品质的视频社交媒体 (yangshipin.cn)](https://www.yangshipin.cn/) 
18. [首页 (pptv.com)](https://www.pptv.com/) 
19. [乐视视频 - 乐视旗下专业的影视剧视频网站_高清视频在线观看 (le.com)](https://www.le.com/) 
20. [搜狐视频-国内综合视频网站,正版高清视频在线观看,原创视频上传,全网视频搜索 (sohu.com)](https://tv.sohu.com/) 

## 1.3 音乐

1. [网易云音乐 (163.com)](https://music.163.com/) 
2. [QQ音乐-千万正版音乐海量无损曲库新歌热歌天天畅听的高品质音乐平台！](https://y.qq.com/) 
3. [酷我音乐-无损音质正版在线试听网站 (kuwo.cn)](https://kuwo.cn/) 
4. [酷狗音乐 - 就是歌多！小说相声也很多！ (kugou.com)](https://www.kugou.com/) 
5. [咪咕音乐网_放肆听·趣玩乐 (migu.cn)](https://music.migu.cn/v3) 
6. [‎Apple Music](https://music.apple.com/) 
7. [Spotify – 网络播放器](https://open.spotify.com/) 
8. [Amazon Music Unlimited | Stream 100 Million Songs & Podcasts](https://music.amazon.com/) 
9. [YouTube Music](https://music.youtube.com/) 
10. [TIDAL - High Fidelity Music Streaming](https://tidal.com/) 
11. [Music and Podcasts, Free and On-Demand | Pandora](https://www.pandora.com/) 

## 1.4 直播

1. [虎牙直播-技术驱动娱乐-弹幕式互动直播平台 (huya.com)](https://www.huya.com/) 
2. [斗鱼 - 每个人的直播平台 (douyu.com)](https://www.douyu.com/) 
3. [YY-全民娱乐的互动直播平台](https://www.yy.com/) 
4. [花椒直播 (huajiao.com)](https://www.huajiao.com/) 
5. [映客-看直播，玩直播，尽在映客 (inke.cn)](https://www.inke.cn/) 
6. [网易CC直播 - 大型游戏娱乐直播平台 (163.com)](https://cc.163.com/) 
7. [ニコニコ生放送 (nicovideo.jp)](https://live.nicovideo.jp/) 
8. [AfreecaTV](https://afreecatv.com/) 
9. [Twitch](https://www.twitch.tv/) 

## 1.5 社交

1. [知乎 - 知乎 (zhihu.com)](https://www.zhihu.com/) 
2. [微博 – 随时随地发现新鲜事 (weibo.com)](https://weibo.com/) 
3. [豆瓣 (douban.com)](https://www.douban.com/) 
4. [百度贴吧——全球领先的中文社区 (baidu.com)](https://tieba.baidu.com/) 
5. [小红书 (xiaohongshu.com)](https://www.xiaohongshu.com/) 
6. [酷安 - 发现科技新生活 (coolapk.com)](https://www.coolapk.com/) 
7. [NGA玩家社区](https://bbs.nga.cn/) 
8. [虎扑体育-虎扑网 (hupu.com)](https://www.hupu.com/app/) 
9. [卡饭论坛\_最好的软件论坛_讨论 - 互助分享 - 大气谦和! (kafan.cn)](https://bbs.kafan.cn/) 
10. [美食\_生活\_团购\_旅游\_电影\_优惠券 - 大众点评网 (dianping.com)](https://www.dianping.com/) 
11. [微信，是一个生活方式 (qq.com)](https://weixin.qq.com/) 
12. [I'm QQ - 每一天，乐在沟通](https://im.qq.com/index) 
13. [QQ空间-分享生活，留住感动](https://qzone.qq.com/) 
14. [TIM (qq.com)](https://office.qq.com/) 
15. [天涯社区_全球华人网上家园 (tianya.cn)](http://www.tianya.cn/) 
16. [人人 - 加入人人，找到老同学，结识新朋友 (renren.com)](http://www.renren.com/) 
17. [Soul 官方网站-年轻人的社交元宇宙 (soulapp.cn)](https://www.soulapp.cn/) 
18. [LOFTER（乐乎） - 让兴趣，更有趣](https://www.lofter.com/) 
19. [陌陌官网 (immomo.com)](http://www.immomo.com/) 
20. [钉钉，让进步发生 (dingtalk.com)](https://www.dingtalk.com/) 
21. [企业微信 (qq.com)](https://work.weixin.qq.com/) 
22. [探索 / Twitter](https://twitter.com/) 
23. [Facebook](https://www.facebook.com/) 
24. [Instagram](https://www.instagram.com/) 
25. [TikTok - Make Your Day](https://www.tiktok.com/) 
26. [Tumblr 上的热门话题](https://www.tumblr.com/) 
27. [Discord | Your Place to Talk and Hang Out](https://discord.com/) 
28. [Reddit - Dive into anything](https://www.reddit.com/) 

## 1.6 出行

1. [中国铁路12306网站](https://www.12306.cn/index/) 
2. [携程旅行网官网:酒店预订,机票预订查询,旅游度假,商旅管理 (ctrip.com)](https://www.ctrip.com/) 
3. [【去哪儿网】机票查询预订，酒店预订，旅游团购，度假搜索，门票预订-去哪儿网Qunar.com](https://www.qunar.com/) 
4. [飞机票查询-机票预订、酒店预订查询、客栈民宿、旅游度假、门票签证【飞猪旅行】 (fliggy.com)](https://www.fliggy.com/) 
5. [驴妈妈旅游网 (lvmama.com)](http://www.lvmama.com/) 
6. [百度地图 (baidu.com)](https://map.baidu.com/) 
7. [高德地图 (amap.com)](https://www.amap.com/) 
8. [腾讯地图 (qq.com)](https://map.qq.com/) 
9. [搜狗地图 (sogou.com)](http://map.sogou.com/) 已下线，并入腾讯地图
10. [Google 地图](https://www.google.com/maps/)  
11. [首页-滴滴官网 (didiglobal.com)](https://www.didiglobal.com/) 
12. [神州专车-接机，送机，预约用车，企业用车，专人专车，随叫随到！ (10101111.com)](https://www.10101111.com/) 
13. [美团打车-手机打车_出租车|打车司机端 (meituan.com)](https://dache.meituan.com/) 
14. [天气网 (weather.com.cn)](http://www.weather.com.cn/) 
15. [饿了么-网上订餐\_外卖_饿了么订餐官网 (ele.me)](https://www.ele.me/) 
16. [美团网-美食\_团购\_外卖\_酒店\_旅游\_电影票\_吃喝玩乐全都有 (meituan.com)](https://www.meituan.com/) 
17. [哈啰 (hello-inc.com)](https://www.hello-inc.com/) 
18. [青桔单车 (qingjubike.com)](http://www.qingjubike.com/#/home) 

## 1.7 阅读

1. [小说,小说网,最新热门小说-起点中文网_阅文集团旗下网站 (qidian.com)](https://www.qidian.com/) 
2. [小说,小说网,最新热门小说-QQ阅读_阅文集团旗下网站](https://book.qq.com/) 
3. [小说_17K小说网|最新小说下载-一起免费看小说](https://www.17k.com/) 
4. [小说,小说网-纵横中文网|最热门的免费小说网 (zongheng.com)](http://book.zongheng.com/) 
5. [微信读书-正版书籍小说免费阅读 (qq.com)](https://weread.qq.com/) 
6. [刺猬猫官网-异世界的阅读方式 (ciweimao.com)](https://mip.ciweimao.com/) 
7. [刺猬猫 - 网页版 (ciweimao.com)](https://www.ciweimao.com/) 在维护
8. [菠萝包轻小说-SF轻小说国内最大轻小说原创网站|天火互动传媒 (sfacg.com)](http://www.sfacg.com/) 
9. [不可能的世界 (bkneng.com)](https://wenxue.bkneng.com/) 
10. [飞卢小说_免费小说阅读,精彩好看的小说网|创作无极限,阅读有精彩！ (faloo.com)](http://faloo.com/) 
11. [火文科技旗下二次元轻小说原创平台-次元姬 (ciyuanji.com)](https://www.ciyuanji.com/) 
12. [小说,小说网-塔读小说网|免费阅读最新热门小说 (tadu.com)](https://www.tadu.com/) 
13. [网易云阅读--海量新闻、精彩资讯、图书、免费小说、漫画，免费畅读 (163.com)](https://yuedu.163.com/) 
14. [网易蜗牛读书，时间出新知 (163.com)](https://du.163.com/) 
15. [多看阅读(duokan.com) - 海量畅销电子书免费试读，数百万读者阅读首选](https://www.duokan.com/pc/) 
16. [【磨铁文学】原创文学小说|好看的经典文学类小说推荐|优秀文学小说排行榜-磨铁文学网 (motie.com)](https://www.motie.com/wenxue) 
17. [掌阅科技-引领品质阅读 (zhangyue.com)](https://www.zhangyue.com/) 
18. [七猫中文网-全本免费小说-免费小说排行榜 (qimao.com)](https://www.qimao.com/) 
19. [番茄小说网--番茄小说旗下原创文学平台 (fanqienovel.com)](https://fanqienovel.com/) 
20. [咪咕文学网—咪咕数媒旗下作者服务平台 (cmread.com)](https://www.cmread.com/wenxuenew/) 
21. [息壤中文网—原创精品阅读平台 (xrzww.com)](https://www.xrzww.com/) 
22. [书旗小说\_免费小说大全\_书旗网,书旗网\_书旗免费小说_阿里巴巴旗下原创文学平台 (shuqi.com)](https://www.shuqi.com/) 
23. [晋江文学城 (jjwxc.net)](https://www.jjwxc.net/) 
24. [好看的言情小说推荐_女生小说在线阅读 – 潇湘书院 (xxsy.net)](https://www.xxsy.net/) 
25. [红袖读书_好看的小说免费阅读 - 阅文集团旗下网站 (hongxiu.com)](https://www.hongxiu.com/) 
26. [原创作品 | 豆瓣阅读 (douban.com)](https://read.douban.com/) 
27. [京东读书 (jd.com)](https://e-m.jd.com/) 
28. [哔哩哔哩漫画 - bilibili 正版漫画平台](https://manga.bilibili.com/)
29. [动漫 - 腾讯动漫官方网站 - 首页 (qq.com)](https://ac.qq.com/) 
30. [国内知名原创动漫平台\_斗破苍穹漫画官网_知音漫客网 (zymk.cn)](https://www.zymk.cn/) 
31. [快看\_官方漫画_漫画大全免费在线观看 (kuaikanmanhua.com)](https://www.kuaikanmanhua.com/) 
32. [咚漫漫画官网|咚咚手指 看看漫画 (dongmanmanhua.cn)](https://www.dongmanmanhua.cn/) 
33. [触漫：超好玩的泛二次元创作社区 (chumanapp.com)](https://www.chumanapp.com/) 
34. [漫画 在线漫画 原创漫画 漫画大全-动漫之家- 首页 (dmzj.com)](https://www.dmzj.com/) 
35. [国内原创在线漫画平台_好看的漫画大全 - 漫客栈 (mkzhan.com)](https://www.mkzhan.com/) 
36. [微博动漫-官方漫画 (weibo.com)](https://manhua.weibo.com/) 
38. [有声小说,听书,听小说,听故事,听广播 - 喜马拉雅 (ximalaya.com)](https://www.ximalaya.com/) 
39. [猫耳FM\_来自二次元的声音\_( :3」∠)_M站 (missevan.com)](https://www.missevan.com/) 
40. [有声小说-有声读物-电台广播在线听书-蜻蜓FM (qingting.fm)](https://www.qingting.fm/) 
41. [Nightfall - 豆瓣FM (douban.com)](https://fm.douban.com/) 

## 1.8 公司

1. [小米官网 - Xiaomi 13系列，Xiaomi Mix Fold 2，MIUI14，小米徕卡影像大赛](https://www.mi.com/) 
2. [华为 - 构建万物互联的智能世界 (huawei.com)](https://www.huawei.com/)  
3. [【荣耀官网】荣耀手机-荣耀Magic Vs/荣耀80系列-HONOR手机 (hihonor.com)](https://www.hihonor.com/cn/) 
4. [OPPO Find N2 系列 轻巧好用，值得重用 | OPPO 官方网站](https://www.oppo.com/cn/) 
5. [vivo官方网站 - S16系列 轻薄人像旗舰](https://www.vivo.com/) 
6. [魅族官网商城-提供魅族品牌手机、数码生活周边及子品牌产品的预约和购买 (meizu.com)](https://www.meizu.com/) 
7. [中兴手机官网 – 中兴手机官网 (ztedevices.com)](https://www.ztedevices.com/cn/) 
8. [一加手机官方网站 (oneplus.com)](https://www.oneplus.com/cn) 
9. [真我realme官方商城-真我10系列新品发布](https://www.realme.com/) 
10. [红魔官网 - 努比亚 (nubia.com)](https://www.nubia.com/cn/) 
11. [黑鲨手机_黑鲨游戏手机-黑鲨官网 (blackshark.com)](http://www.blackshark.com/) 
12. [三星电子 中国 | 三星手机 | 电视 | 显示器 固态硬盘 | 冰箱 洗衣机等产品官网 (samsung.com)](https://www.samsung.com/cn/) 
13. [Apple (中国大陆) - 官方网站](https://www.apple.com.cn/) 
14. [联想\_lenovo笔记本电脑\_平板电脑\_手机\_台式机\_服务器\_外设数码\_联想官网](https://www.lenovo.com.cn/) 
15. [华硕商城ASUS\_华硕官网_华硕电脑官方直营商城，购笔记本电脑、轻薄本、游戏本、享一年意外险](https://www.asus.com.cn/) 
16. [戴尔笔记本电脑\_台式电脑\_服务器\_电脑配件\_戴尔官方网站 | Dell](https://www.dell.com/zh-cn) 
17. [Acer 宏碁电脑（上海）有限公司](https://www.acer.com.cn/index.html) 
18. [笔记本、台式机、打印机、墨盒与硒鼓 | 惠普中国 (hp.com)](https://www.hp.com/cn-zh/home.html) 
19. [Microsoft - 云、计算机、应用和游戏](https://www.microsoft.com/zh-cn/) 
20. [英特尔 | 数据中心解决方案、物联网和电脑创新 (intel.cn)](https://www.intel.cn/content/www/cn/zh/homepage.html) 
21. [同超越，共成就_ | AMD官方网站](https://www.amd.com/zh-hans) 
22. [IBM - 中国 | IBM](https://www.ibm.com/cn-zh) 
23. [Oracle | Cloud Applications and Cloud Platform](https://www.oracle.com/) 
24. [Qualcomm-美国高通公司官方网站](https://www.qualcomm.cn/) 
25. [Adobe：创意、营销和文档管理解决方案](https://www.adobe.com/cn/) 
26. [SonyChinaCorporatePortal首页-索尼（中国）有限公司企业官网](https://www.sony.com.cn/) 
27. [台湾积体电路制造股份有限公司 (tsmc.com)](https://www.tsmc.com/schinese) 
28. [首页|长江存储官网-长江存储 (ymtc.com)](https://www.ymtc.com/) 
29. [首页 - 长鑫存储技术有限公司 (cxmt.com)](https://www.cxmt.com/) 
30. [字节跳动 (bytedance.com)](https://www.bytedance.com/zh/) 
31. [蚂蚁集团 (antgroup.com)](https://www.antgroup.com/) 
32. [DJI 大疆创新 - 官方网站](https://www.dji.com/cn) 
33. [科大讯飞 - 用人工智能建设美好世界 (iflytek.com)](https://www.iflytek.com/index.html) 
34. [海尔集团官网-物联网生态品牌 (haier.com)](https://www.haier.com/) 
35. [得力集团有限公司 (nbdeli.com)](https://www.nbdeli.com/) 
36. [晨光文具 (mg-pen.com)](https://www.mg-pen.com/) 
37. [珠海格力电器股份有限公司网站 (gree.com)](https://www.gree.com/) 
38. [首页 (midea.com)](https://www.midea.com/cn) 
39. [贵州茅台集团 (china-moutai.com)](https://www.china-moutai.com/) 
40. [五粮液集团 (wuliangye.com.cn)](https://www.wuliangye.com.cn/zh/main/index.html) 

## 1.9 游戏

1. [王者荣耀官方网站-腾讯游戏 (qq.com)](https://pvp.qq.com/) 
2. [英雄联盟手游官网 - 腾讯游戏 (qq.com)](https://lolm.qq.com/main.html) 
3. [金铲铲之战-英雄联盟云顶之弈正版授权手游 (qq.com)](https://jcc.qq.com/#/index) 
4. [官网首页- 和平精英-官方网站-腾讯游戏 (qq.com)](https://gp.qq.com/main.shtml) 
5. [《阴阳师》手游官网 镜守云归 (163.com)](https://yys.163.com/) 
6. [《第五人格》官方网站 (163.com)](https://id5.163.com/index.html) 
7. [我的世界Minecraft中国版官方网站——你想玩的，这里都有 (163.com)](https://mc.163.com/index.html) 
8. [光遇手游官网-光是遇见就很美好 (163.com)](https://sky.163.com/index.html) 
9. [《决战！平安京》手游官网-网易顶级MOBA手游 阴阳师IP公平对战手游 (163.com)](http://moba.163.com/index.html) 
10. [网易《明日之后》官方网站-第五季 (163.com)](https://mrzh.163.com/index.html) 
11. [《梦幻西游》手游官网-人人都玩，无处不在 (163.com)](https://my.163.com/) 
12. [《部落冲突》官方网站 (arkgames.com)](http://coc.arkgames.com/) 
13. [《地铁跑酷》官网-现在下载送官网专属福利-乐逗游戏 (uu.cc)](https://pao.uu.cc/) 
14. [《崩坏3》官方网站 - 为世界上所有的美好而战 (bh3.com)](https://www.bh3.com/) 
15. [《碧蓝航线》官方网站，此身为舰，即刻出战！ (bilibili.com)](https://game.bilibili.com/blhx/) 
16. [少女前线 (sunborngame.com)](https://gf-cn.sunborngame.com/) 
17. [明日方舟 - Arknights (hypergryph.com)](https://ak.hypergryph.com/) 
18. [战双帕弥什 (kurogame.com)](https://pns.kurogame.com/) 
19. [《幻塔》官网——轻科幻开放世界手游 (wanmei.com)](https://ht.wanmei.com/main.html) 
20. [《炉石传说》官方网站_暴雪首款免费休闲卡牌网游 (blizzard.cn)](https://hs.blizzard.cn/) 
21. [官方网站 | Minecraft](https://www.minecraft.net/zh-hans) 
22. [绝地求生-绝地求生官方网站-腾讯游戏 (qq.com)](https://pubg.qq.com/main.shtml) 
23. [QQ飞车官网首页 - QQ飞车官方网站-腾讯游戏-竞速网游王者 突破300万同时在线](https://speed.qq.com/main.shtml) 
24. [英雄联盟官方网站-腾讯游戏 (qq.com)](https://lol.qq.com/) 
25. [CSGO官方网站 - 反恐精英：全球攻势 - 国服五周年 (wanmei.com)](https://csgo.wanmei.com/)  
26. [穿越火线-CF-官方网站-腾讯游戏-兄弟，下把一起 (qq.com)](https://cf.qq.com/main.shtml) 
27. [天涯明月刀-官方网站-腾讯游戏-此爱绵绵冬季资料片同心系统开启！ (qq.com)](https://wuxia.qq.com/) 
28. [魔兽世界 (wowchina.com)](https://www.wowchina.com/zh-cn/) 
29. [《最终幻想14》官方网站-新版本好评开放 人气MMORPG大作 (sdo.com)](https://ff.web.sdo.com/web8/index.html#/index) 
30. [DOTA2 - 刀塔官方网站 - 2022年勇士令状正式上线](https://www.dota2.com.cn/) 
31. [EVE国服官网\_EVE Online\_网易EVE官网\_星战前夜_晨曦 (163.com)](https://evepc.163.com/) 
32. [《逆水寒》官方网站 - 新资料片【致江湖】 (163.com)](https://n.163.com/index.html) 
33. [《永劫无间》官方网站-咏武斗剑大会 现已开启 (yjwujian.cn)](https://www.yjwujian.cn/)
34. [《坦克世界》首页 (wotgame.cn)](https://wotgame.cn/) 
35. [《原神》官方网站-全新3.3版本 「六入尽明，诸相皆无」上线！ (mihoyo.com)](https://ys.mihoyo.com/) 
36. [TapTap | 发现好游戏](https://www.taptap.cn/) 
37. [Ubisoft | Welcome to the official Ubisoft website](https://www.ubisoft.com/en-us/) 
38. [欢迎来到 Steam (steampowered.com)](https://store.steampowered.com/) 
39. [Epic游戏商城 | 下载畅玩 PC 平台游戏、模组、DLC 和更多 – Epic Games](https://store.epicgames.com/zh-CN/) 
40. [Electronic Arts Home Page - Official EA Site](https://www.ea.com/) 
41. [WeGame游戏商店 - 发现更大的游戏世界](https://www.wegame.com.cn/) 

## 1.10 资讯

1. [新华网_让新闻离你更近 (xinhuanet.com)](http://www.xinhuanet.com/)
2. [今日头条 (toutiao.com)](https://www.toutiao.com/) 
3. [人民日报-人民网 (people.com.cn)](http://paper.people.com.cn/rmrb) 
4. [凤凰网 (ifeng.com)](https://www.ifeng.com/) 
5. [网易 (163.com)](https://www.163.com/) 
6. [观察者网 (guancha.cn)](https://www.guancha.cn/) 
7. [光明网_新闻视野、文化视角、思想深度、理论高度 (gmw.cn)](https://www.gmw.cn/) 
8. [新浪网 (sina.com.cn)](https://www.sina.com.cn/) 
9. [南方周末 (infzm.com)](http://www.infzm.com/) 
10. [财联社-主流财经新闻集团和财经通讯社-CLS.CN](https://www.cls.cn/) 
11. [财新网 (caixin.com)](https://www.caixin.com/) 
12. [ZAKER新闻 (myzaker.com)](http://www.myzaker.com/) 
13. [三联生活周刊-一本杂志和他倡导的生活 (lifeweek.com.cn)](http://www.lifeweek.com.cn/) 
14. [新闻中心-腾讯网 (qq.com)](https://news.qq.com/) 
15. [新闻频道_央视网(cctv.com)](https://news.cctv.com/) 
16. [中国日报网-传播中国，影响世界 (chinadaily.com.cn)](http://cn.chinadaily.com.cn/) 
17. [搜狐 (sohu.com)](https://www.sohu.com/) 
18. [36氪_让一部分人先看到未来 (36kr.com)](https://www.36kr.com/) 
19. [少数派 - 高效工作，品质生活 (sspai.com)](https://sspai.com/) 
20. [IT之家 (ithome.com)](https://www.ithome.com/) 
21. [小众软件 - 分享免费、小巧、实用、有趣、绿色的软件 (appinn.com)](https://www.appinn.com/) 
22. [爱范儿 · 让未来触手可及 (ifanr.com)](https://www.ifanr.com/) 
23. [极客公园-Geek Things Up! (geekpark.net)](https://www.geekpark.net/) 
24. [Topbook | 高效生活视频书](https://topbook.cc/overview) 
25. [月光博客-关注互联网和搜索引擎的IT科技博客 (williamlong.info)](https://www.williamlong.info/) 
26. [奇客资讯网 (solidot.org)](https://www.solidot.org/) 
27. [虎嗅网 (huxiu.com)](https://www.huxiu.com/) 
28. [数字尾巴 分享美好数字生活 (dgtle.com)](https://www.dgtle.com/) 
29. [极客网 | 科技使能新商业-FromGeek.com](https://www.fromgeek.com/) 
30. [钛媒体-专业无止境 (tmtpost.com)](https://www.tmtpost.com/) 
31. [硅发布 – 帮您观察真正的硅谷 – 关注微信号（Guifabucom），获得更快的文章更新](http://www.guifabu.com/) 
32. [品玩-有品好玩的科技，一切与你有关 (pingwest.com)](https://www.pingwest.com/) 
33. [DoNews-创新无边界](https://www.donews.com/) 
34. [cnBeta.COM - 中文业界资讯站](https://www.cnbeta.com.tw/) 
35. [简讯App官方网站 (tipsoon.com)](https://www.tipsoon.com/) 
36. [动点科技 - 关注值得关注的科技创新，全球最具影响力的中英双语科技媒体 (technode.com)](https://cn.technode.com/) 
37. [中关村在线 - 大中华区专业IT网站 - The valuable and professional IT business website in Greater China (zol.com.cn)](https://www.zol.com.cn/) 
38. [AlleyRead - 重塑你的信息源](https://alleyread.com/) 

# 工具类

## 2.1 搜索

1. [百度一下，你就知道 (baidu.com)](https://www.baidu.com/) 
2. [Google](https://www.google.com/) 
3. [必应 - 国内版(bing.com)](https://cn.bing.com/) 
4. [必应 - 国际版 (bing.com)](https://www.bing.com/) 
5. [F 搜 (fsoufsou.com)](https://fsoufsou.com/) 
6. [Yandex](https://yandex.com/) 
7. [DuckDuckGo — 保有隐私，可以很简单。](https://duckduckgo.com/?q=) 
8. [360搜索，SO靠谱](https://www.so.com/) 
9. [搜狗搜索引擎 - 上网从搜狗开始 (sogou.com)](http://www.sogou.com/) 
10. [无追搜索 - 隐私保护，化繁为简 (wuzhuiso.com)](https://www.wuzhuiso.com/) 
11. [开发者搜索-Beta-让技术搜索更简单高效 (baidu.com)](https://kaifa.baidu.com/) 
12. [勾勾 (webbillion.cn)](https://gogo.webbillion.cn/) 搜索结果基于谷歌
13. [Magi](https://magi.com/) 已暂停服务
14. [SearXNG (dasnetzundich.de)](https://suche.dasnetzundich.de/) 
15. [You.com | The Search Engine You Control](https://you.com/) 
16. [Ecosia - the search engine that plants trees](https://www.ecosia.org/) 
17. [Neeva - Ad-free, private search](https://neeva.com/) 
18. [Startpage - Private Search Engine. No Tracking. No Search History.](https://www.startpage.com/) 
19. [Yahoo Search - Web Search](https://search.yahoo.com/) 
20. [秘迹搜索 (mijisou.com)](https://mijisou.com/) 似乎不能使用
21. [Ask.com - What's Your Question?](https://www.ask.com/) 输入提问，搜索答案
22. [Qwant - The search engine that doesn't know anything about you, and that changes everything!](https://www.qwant.com/) 科学上网才能使用

## 2.2 云盘

1. [阿里云盘 (aliyundrive.com)](https://www.aliyundrive.com/) 
2. [百度网盘 (baidu.com)](https://pan.baidu.com/) 
3. [蓝奏·云存储 (woozooo.com)](https://up.woozooo.com/) 
4. [夸克网盘 (quark.cn)](https://pan.quark.cn/) 
5. [坚果云官网|网盘|云盘|云服务|团队协作软件|同步盘 (jianguoyun.com)](https://www.jianguoyun.com/) 
6. [TeraCLOUD](https://teracloud.jp/en/) 
7. [4shared.com - 免费文件分享及储存](https://www.4shared.com/) 
8. [Box — Secure Cloud Content Management, Workflow, and Collaboration](https://www.box.com/) 
9. [天翼云盘 珍藏美好生活 家庭云|网盘|文件备份|资源分享 (189.cn)](https://cloud.189.cn/) 
10. [115生活，一生相伴](https://115.com/) 
11. [奶牛快传｜免费大文件传输工具，上传下载不限速 CowTransfer | Unlimited Send Large Files](https://cowtransfer.com/) 
12. [MuseTransfer｜文件传输 不限速 高品质](https://musetransfer.com/) 
13. [文叔叔 - 传文件，找文叔叔（大文件、永不限速） (wenshushu.cn)](https://www.wenshushu.cn/) 
14. [PikPak介绍 | PikPak - 极速秒存的私密云盘 (mypikpak.com)](https://mypikpak.com/) 
15. [我的云盘 (chaoxing.com)](http://pan-yz.chaoxing.com/) 
16. [首页-腾讯微云 (weiyun.com)](https://www.weiyun.com/) 
17. [我的云端硬盘 - Google 云端硬盘](https://drive.google.com/) 
18. [我的文件 - OneDrive (live.com)](https://onedrive.live.com/) 
19. [中国移动云盘-不限速免流量的云盘 (139.com)](https://yun.139.com/) 
20. [钛盘 - 超好用的文件中转站 (tmp.link)](https://tmp.link/) 
21. [123云盘 (123pan.com)](https://www.123pan.com/) 
22. [iCloud](https://www.icloud.com/) 
23. [Dropbox.com](https://www.dropbox.com/) 
24. [MEGA](https://mega.io/) 
25. [城通网盘 (ctfile.com)](https://www.ctfile.com/) 
26. [飞猫盘｜文件加速传输工具｜云盘｜橘猫旗下新概念云平台 (feimaoyun.com)](https://www.feimaoyun.com/home) 
27. [迅雷-全球共享计算与区块链创领者 (xunlei.com)](https://www.xunlei.com/)  

## 2.3 邮箱

1. [QQ邮箱](https://mail.qq.com/) 
2. [163网易免费邮-你的专业电子邮局](https://mail.163.com/) 
3. [阿里邮箱个人版-阿里云 (aliyun.com)](https://mail.aliyun.com/) 
4. [钉钉邮箱 (dingtalk.com)](https://page.dingtalk.com/wow/dingtalk/act/dingemail/) 
5. [Microsoft Outlook 个人电子邮件和日历 | Microsoft 365](https://outlook.live.com/mail/0/) 
6. [Gmail：免费、私密且安全的电子邮件 | Google Workspace](https://mail.google.com/mail/) 
7. [搜狐闪电邮箱 (sohu.com)](https://mail.sohu.com/) 
8. [中国移动139邮箱-手机号就是邮箱号 (10086.cn)](https://mail.10086.cn/) 
9. [189邮箱-爱简单](https://webmail30.189.cn/w2/index.html) 
10. [中国电信企业邮箱-登录页面 (21cn.net)](https://mail.21cn.net/) 
11. [花瓣邮箱 - 华为推出的电子邮件服务 (petalmail.com)](https://www.petalmail.com/#/) 
12. [新浪邮箱 (sina.com.cn)](https://mail.sina.com.cn/) 
13. [Yandex Mail — reliable and easy to use email with spam protection](https://mail.yandex.com/) 
14. [Email Hosting | Secure Business Email for your organization - Zoho Mail](https://www.zoho.com/mail/) 
15. [Fastmail | We Respect Your Privacy & Put You in Control](https://www.fastmail.com/) 
16. [Proton Mail — Get a private, secure, and encrypted email](https://proton.me/mail) 

## 2.4 文件处理

1. [Convertio — 文件转换器](https://convertio.co/zh/) 
2. [CloudConvert](https://cloudconvert.com/) 
3. [ClipDrop](https://clipdrop.co/) 
4. [PDF转Word | 免费在线PDF转Word | PDF转Word转换器 | PDF转化速度快 | 首页 (alltoall.net)](https://www.alltoall.net/) 
5. [在线翻译|转换工具-PDF在线转换-迅捷办公 (xunjiepdf.com)](https://www.xunjiepdf.com/tool) 
6. [图片转文字在线 - 图片文字提取 - 网页OCR文字识别 - 白描网页版 (baimiaoapp.com)](https://web.baimiaoapp.com/) 
7. [PearOCR，在线图片转文字，免费OCR，在线图片文字提取，本地运算，无上传](https://pearocr.com/#/) 
8. [Squoosh - 图片压缩](https://squoosh.app/) 
9. [docsmall - 免费在线图片压缩、GIF压缩工具、PDF压缩工具、PDF合并工具、PDF分割工具](https://docsmall.com/) 
10. [Picdiet - 极速在线压缩80%图片体积](https://www.picdiet.com/zh-cn) 
11. [AI Image Upscaler - Upscale Photo, Cartoons in Batch Free (imgupscaler.com)](https://imgupscaler.com/) 
12. [waifu2x - 图片放大 (udp.jp)](https://waifu2x.udp.jp/index.zh-CN.html) 
13. [图片拼接——免费在线拼接多个图片成长图 (zuohaotu.com)](http://www.zuohaotu.com/image-merge.aspx) 
14. [在线抠图软件_图片去除背景 | remove.bg – remove.bg](https://www.remove.bg/zh) 
15. [消除或者替换图像背景，无需上传图像 - BgSub](https://bgsub.cn/) 

## 2.5 翻译

1. [百度翻译-200种语言互译、沟通全世界！ (baidu.com)](https://fanyi.baidu.com/) 
2. [Google 翻译](https://translate.google.com/?hl=zh-CN) 
3. [Bing Microsoft Translator - 从英语翻译](https://www.bing.com/translator?mkt=zh-CN) 
4. [DeepL翻译：全世界最准确的翻译](https://www.deepl.com/translator) 
5. [搜狗翻译 - 我的贴身智能翻译专家 (sogou.com)](https://fanyi.sogou.com/text) 
6. [腾讯翻译君 - 在线翻译 (qq.com)](https://fanyi.qq.com/) 
7. [在线翻译_有道 (youdao.com)](https://fanyi.youdao.com/index.html#/) 
8. [彩云小译 - 在线翻译 (caiyunapp.com)](https://fanyi.caiyunapp.com/#/) 


# 资源类

## 3.1 图片

1. [Beautiful Free Images & Pictures | Unsplash](https://unsplash.com/) 
2. [Awesome Wallpapers - wallhaven.cc](https://wallhaven.cc/) 
3. [Simple Desktops](http://simpledesktops.com/) 
4. [免费正版高清图片素材库 超过2.7百万张优质图片和视频素材可供免费使用和下载 - Pixabay](https://pixabay.com/zh/) 
5. [免费素材图片 (pexels.com)](https://www.pexels.com/zh-cn/) 
6. [Desktop wallpapers hd, free desktop backgrounds (wallpaperscraft.com)](https://wallpaperscraft.com/) 
7. [必应每日高清壁纸 - 精彩，从这里开始 (ioliu.cn)](https://bing.ioliu.cn/) 
8. [DeviantArt - The Largest Online Art Gallery and Community](https://www.deviantart.com/) 
9. [Wallpaper Abyss - 高清壁纸, 桌面背景 (alphacoders.com)](https://wall.alphacoders.com/?lang=Chinese) 
10. [极简壁纸\_海量电脑桌面壁纸美图\_4K超高清_最潮壁纸网站 (zzzmh.cn)](https://bz.zzzmh.cn/index) 
11. [花瓣网_陪你做生活的设计师（创意灵感天堂，搜索、发现设计灵感、设计素材） (huaban.com)](https://huaban.com/) 
12. [世界著名的壁纸网站 电脑桌面壁纸 - WallHere 壁纸库](https://wallhere.com/) 
13. [Hippopx - 精美的免版权图库](https://www.hippopx.com/zh) 
14. [首页 - colorhub.me(调色板) - 高清无版权图片，个人和商业用途免费](https://www.colorhub.me/) 
15. [pixiv](https://www.pixiv.net/) 
16. [堆糖，美图壁纸兴趣社区 (duitang.com)](https://www.duitang.com/) 
17. [ArtStation - All Channels](https://www.artstation.com/?sort_by=trending) 
18. [35PHOTO - social network for professional photographers](https://35photo.pro/) 
19. [HD/4K/5K Resolution Wallpapers/Backgrounds ▪ Wallroom.io](https://wallroom.io/) 
20. [CGWallpapers.com](https://www.cgwallpapers.com/) 
21. [Papers.co - Best wallpapers](https://papers.co/) 
22. [Piqsels - 精美的免版税图库](https://www.piqsels.com/zh)
23. [美图集-高质量图片免费下载 (ihansen.org)](https://photo.ihansen.org/) 
24. [致美化 - 最专业的桌面美化交流平台 - 漫锋网 (zhutix.com)](https://zhutix.com/) 

## 3.2 字体

1. [猫啃网，最新最全的可免费商用中文字体下载网站！喵啃~ (maoken.com)](https://www.maoken.com/) 
2. [字体天下-提供各类字体的免费下载和在线预览服务 (fonts.net.cn)](https://www.fonts.net.cn/) 
3. [100font.com - 免费字体下载 - 免费商用字体下载网站](https://www.100font.com/) 
4. [汉仪字库-用心绽放文字之美 (hanyi.com.cn)](https://www.hanyi.com.cn/) 
5. [仓耳字库 - 仓耳字体|仓耳字库|屏幕显示字体|艺术字体|免费字体|仓耳字库官网 (tsanger.cn)](http://www.tsanger.cn/) 
6. [Browse Fonts - Google Fonts](https://fonts.google.com/) 
7. [Google Fonts | 谷歌字体中文版 | GoogleFonts](https://www.font.im/) 
8. [方正字库官网 (foundertype.com)](https://www.foundertype.com/) 
9. [中文字体库 (chinese-font.netlify.app)](https://chinese-font.netlify.app/#/) 

## 3.3 图标

1. [iconfont-阿里巴巴矢量图标库](https://www.iconfont.cn/) 
2. [ByteDance IconPark (oceanengine.com)](https://iconpark.oceanengine.com/) 
3. [Vector Icons and Stickers - PNG, SVG, EPS, PSD and CSS (flaticon.com)](https://www.flaticon.com/) 
4. [Feather – Simply beautiful open source icons (feathericons.com)](https://feathericons.com/) 
5. [Iconhub](https://iconhub.io/#) 
6. [Radix Icons (radix-ui.com)](https://icons.radix-ui.com/) 
7. [Remix Icon - Open source icon library](https://remixicon.com/) 
8. [IcoMoon App - Icon Font, SVG, PDF & PNG Generator](https://icomoon.io/app/#/select) 
9. [Tabler Icons: over 3050 vector icons for web design (tabler-icons.io)](https://tabler-icons.io/) 
10. [Simple Icons](https://simpleicons.org/zh-CN/)
11. [Free Line Icons for Designers and Developers - Lineicons](https://lineicons.com/) 
12. [Material Symbols and Icons - Google Fonts](https://fonts.google.com/icons?selected=Material+Icons) 
13. [Heroicons](https://heroicons.com/) 
14. [Health icons](https://healthicons.org/) 
15. [Find Icons with the Perfect Look & Feel | Font Awesome](https://fontawesome.com/icons) 
16. [Ionicons: Premium Open Source Icon Pack for Ionic Framework](https://ionic.io/ionicons) 
17. [Unicons: 4,500+ Free Icon Fonts and SVG Icons - IconScout](https://iconscout.com/unicons) 
18. [Bootstrap Icons · Official open source SVG icon library for Bootstrap (getbootstrap.com)](https://icons.getbootstrap.com/) 
19. [图标库 - 开箱即用的产品设计资源库 | Axure图标 | Axure元件 | Axure组件 | Axure原型 (axmax.cn)](https://axmax.cn/) 

## 3.4 软件

1. [果核剥壳 - 互联网的净土 (ghxi.com)](https://www.ghxi.com/) 
2. [异星软件空间 | 感受不一样的精彩体验！ (yxssp.com)](https://www.yxssp.com/) 
3. [独孤求软 | 常用软件一站齐全 (dugubest.com)](http://www.dugubest.com/) 
4. [蓝鲨 - 让您在互联网的海洋里自由的遨游！ (lan-sha.com)](https://www.lan-sha.com/) 
5. [落尘之木-TO BE THE BEST! (luochenzhimu.com)](https://www.luochenzhimu.com/) 
6. [反斗软件 (apprcn.com)](https://www.apprcn.com/) 
7. [th_sjy 专注软件汉化，Software localization, Sinicization (th-sjy.com)](http://www.th-sjy.com/) 
8. [异次元软件世界 - 软件改变生活！ (iplaysoft.com)](https://www.iplaysoft.com/) 
9. [六音 (6yit.com)](https://www.6yit.com/) 
10. [423Down](https://www.423down.com/) 
11. [大眼仔旭 - 专注视频剪辑、解压、录屏、思维导图等办公资源分享 (dayanzai.me)](http://www.dayanzai.me/) 
12. [佛系软件 - 精品Windows,macOS破解软件下载 (foxirj.com)](https://foxirj.com/) 
13. [无痕哥 - Healer - whg6.com](https://www.whg6.com/) 
14. [殁漂遥 mpyit.com 老殁专注分享十二年](https://www.mpyit.com/) 
15. [哇哦菌-破解软件下载基地,致力实用软件绿色资源分享 (waodown.com)](https://www.waodown.com/) 
16. [花间社 - 免费分享各种软件及教程 (huajclub.com)](https://www.huajclub.com/) 
17. [Nite07的小窝 - 优质软件资源站](https://www.nite07.com/) 
18. [首页\_懒得勤快的博客_互联网分享精神 (ldqk.xyz)](https://ldqk.xyz/) 
19. [分享迷 - 优质精品TV软件、互联网资源分享 (fenxm.com)](https://www.fenxm.com/) 

## 3.5 色卡

1. [Coolors - The super fast color palettes generator!](https://coolors.co/) 
2. [ColorKit - Color Palettes, Gradients, Inspiration, and Color Tools](https://colorkit.co/)
3. [Colors & Fonts (colorsandfonts.com)](https://www.colorsandfonts.com/) 
4. [Color Palettes for Designers and Artists - Color Hunt](https://colorhunt.co/) 
5. [zhongguose － 传统颜色](http://zhongguose.com/) 
6. [中国传统颜色 | 中国色 (2kil.com)](https://www.2kil.com/) 
7. [配色卡\_色彩搭配\_配色工具\_色彩组合 (peiseka.com)](https://peiseka.com/) 
8. [Palettable](https://www.palettable.io/) 
9. [Grabient](https://www.grabient.com/)
10. [uiGradients - Beautiful colored gradients](https://uigradients.com/) 
11. [Fresh Background Gradients | WebGradients.com 💎](https://webgradients.com/) 
12. [ColorSpace - Color Palettes Generator and Color Gradient Tool (mycolor.space)](https://mycolor.space/) 
13. [Gradient buttons (colorion.co)](https://gradientbuttons.colorion.co/) 
14. [Cool Backgrounds](https://coolbackgrounds.io/) 
15. [Gradient Colors Collection Palette - CoolHue 2.0 (webkul.github.io)](https://webkul.github.io/coolhue/) 

## 3.6 导航站

1. [神秘的热心网友 - 收集免费实用有趣的东西，做最好的资源导航 (imyshare.com)](https://imyshare.com/) 
2. [龙轩导航-做个有用的导航 (ilxdh.com)](http://ilxdh.com/) 
3. [爱达杂货铺 | 收集那些有用的东西|爱达导航 (adzhp.net)](https://adzhp.net/) 
4. [阿酷导航 - 优质网站收藏仓库 (coolexe.com)](https://nav.coolexe.com/) 
5. [0x3](https://0x3.com/) 
6. [UPUPMO | UP工具网址导航 | 相信美好, 做一只积极向上的导航](https://www.upupmo.com/) 
7. [首页 - 比格张 (bigezhang.com)](https://bigezhang.com/) 
8. [偷渡鱼\_最好用的网址导航_网址大全 (touduyu.com)](https://touduyu.com/) 
9. [兔二工具 (amp360.net)](https://www.amp360.net/) 
10. [数字生活指南 | 让工作学习生活更高效！guidebook.top](https://nav.guidebook.top/) 
11. [学吧导航 | 四十万学习爱好者都在用的学霸导航网站 (xue8nav.com)](https://www.xue8nav.com/) 
12. [柒夜导航 - 黑科技网站资源集 (qinight.com)](https://nav.qinight.com/) 
13. [万有导航丨一个互联网全职业的聚合资源网址导航 (wanyouw.com)](https://wanyouw.com/) 
14. [科塔学术导航 - 最专业、准确、及时和全面的科研与学术资源导航平台 (sciping.com)](https://site.sciping.com/) 
15. [甲方叭叭设计师的专属设计导航 (jiafangbb.com)](https://jiafangbb.com/) 
16. [优设导航官网 - 设计导航 - 国内专业设计师网站导航 (uisdc.com)](https://hao.uisdc.com/) 
17. [优波设计 - 设计师必备网址导航 ubuuk.com](https://www.ubuuk.com/) 
18. [创造狮 创意工作者导航 (chuangzaoshi.com)](https://chuangzaoshi.com/) 
19. [Seeseed-无穷尽设计可能](https://www.seeseed.com/) 
20. [产品经理导航 | 运营导航-互联网人必备网址导航 (pmbaobao.com)](https://www.pmbaobao.com/) 
21. [个人技术分享-程序员导航cxy521](http://www.cxy521.com/) 
22. [发现优质编程学习资源 - 编程导航 (code-nav.cn)](https://www.code-nav.cn/) 
23. [在线工具 - 你的工具箱 (tool.lu)](https://tool.lu/) 
24. [搜图导航-一款强大且智能的设计师导航 (91sotu.com)](https://www.91sotu.com/) 
25. [有深度的网址导航_趣导航 (qssily.com)](https://qssily.com/) 
26. [V2方圆 – 发掘稀缺资源 v2fy zhaoolee](https://www.v2fy.com/) 
27. [花果山 | 炫猿导航 (xydh.fun)](https://xydh.fun/hgs) 

## 3.7 新标签页

1. [infinity新标签页 (infinitytab.com)](https://www.infinitytab.com/) 
2. [新标签页 (itab.link)](https://go.itab.link/) 
3. [青柠起始页 (limestart.cn)](https://limestart.cn/) 
4. [东东起始页 (cuipc.cn)](http://www.cuipc.cn/) 
5. [MARSTAB](https://www.marstab.com/) 
6. [Renewed Tab](https://renewedtab.com/zh_Hans/) 
7. [小舒同学 - 基于收藏夹的新标签页 | 小舒同学 (xiaoshuapp.com)](https://xiaoshuapp.com/) 
8. [简法主页 (jianfast.com)](https://www.jianfast.com/) 
9. [某柠檬_柠檬味的导航 简约版 (moulem.com)](https://www.moulem.com/j.html) 
10. [Speedceo-做自己的老板！](https://speedceo.cn/) 

## 3.8 应用商店

1. [手机游戏应用商店_软件商店app下载-小米应用商店 (mi.com)](https://app.mi.com/) 
2. [应用宝官网-全网最新最热手机应用游戏下载 (qq.com)](https://sj.qq.com/) 
3. [应用市场 (huawei.com)](https://appgallery.huawei.com/Featured) 
4. [应用汇安卓市场_海量安卓软件,安卓游戏免费下载 - Appchina安卓手机应用官网商店](http://www.appchina.com/) 
5. [侠聚官网_首页 (huluxia.com)](http://www.huluxia.com/) 
6. [Apple](https://www.apple.com/app-store) 
7. [快速、免费、安全地下载APK到安卓 (apkpure.com)](https://apkpure.com/cn/) 
8. [Google Play 上的 Android 应用](https://play.google.com/store/games) 
9. [| F-Droid - Free and Open Source Android App Repository](https://f-droid.org/zh_Hans/packages/) 
10. [APKMirror - Free APK Downloads - Free and safe Android APK downloads](https://www.apkmirror.com/) 
11. [Aptoide | 下载、发现并分享最佳的Android应用和游戏](https://cn.aptoide.com/) 
12. [下载免费的安卓游戏及应用 (apk-dl.com)](https://apk-dl.com/zh) 
13. [9Apps - Download Apps & Games APK 2022 | Official](https://www.9apps.com/) 
14. [豌豆荚手机精灵 豌豆荚手机助手-海量安卓APP应用与游戏免费下载 (wandoujia.com)](https://www.wandoujia.com/)  
15. [创造者日报 - 每天发现有趣的产品 (creatorsdaily.com)](https://creatorsdaily.com/)

## 3.9 学习

1. [首页 - 课程图谱 - 在线公开课的知识图谱 (coursegraph.com)](https://coursegraph.com/) 
2. [中国大学MOOC(慕课)_国家精品课程在线学习平台 (icourse163.org)](https://www.icourse163.org/) 
3. [网易公开课 (163.com)](https://open.163.com/) 
4. [网易云课堂 - 悄悄变强大 (163.com)](https://study.163.com/) 
5. [百度文库 - 让每个人平等地提升自我 (baidu.com)](https://wenku.baidu.com/) 
6. [学堂在线 - 精品在线课程学习平台 (xuetangx.com)](https://www.xuetangx.com/) 
7. [超星慕课 (chaoxing.com)](http://mooc.chaoxing.com/) 
8. [全历史 (allhistory.com)](https://www.allhistory.com/) 
9. [ExcelHome - 全球极具影响力的Excel门户,Office视频教程培训中心](https://www.excelhome.net/) 
10. [oeasy,会玩才会学](http://oeasy.org/) 
11. [考试酷(examcoo)-永久免费的电子作业与在线考试系统云平台](https://www.examcoo.com/) 
12. [Crash Course 中文字幕组](https://crashcourse.club/) 
13. [默沙东诊疗手册 (msdmanuals.cn)](https://www.msdmanuals.cn/) 
14. [doyoudo](https://www.doyoudo.com/) 
15. [1000+ Free English Lessons with ESL Worksheets - ESLBuzz Learning English](https://www.eslbuzz.com/) 
16. [YouZack-英语听力精听、背单词](https://www.youzack.com/)
18. [漢典 (zdic.net)](https://www.zdic.net/) 
19. [译学馆 – 知识无疆界 (yxgapp.com)](https://www.yxgapp.com/) 
20. [懒人Excel - Excel 函数公式、操作技巧、数据分析、图表模板、VBA、数据透视表教程 (lanrenexcel.com)](https://www.lanrenexcel.com/) 
21. [Coursera | Degrees, Certificates, & Free Online Courses](https://www.coursera.org/) 
22. [粉笔网 (fenbi.com)](https://fenbi.com/page/home) 
23. [可汗学院 | 免费在线课程, 讲解以及练习 (khanacademy.org)](https://zh.khanacademy.org/) 
24. [TED: Ideas Worth Spreading](https://www.ted.com/) 
25. [edX | Free Online Courses by Harvard, MIT, & more | edX](https://www.edx.org/) 
26. [站酷ZCOOL-设计师互动平台-打开站酷，发现更好的设计！](https://www.zcool.com.cn/) 

# 编程类

## 4.1 代码托管

1. [GitHub](https://github.com/) 
2. [Gitee - 基于 Git 的代码托管和研发协作平台](https://gitee.com/) 
3. [CODING DevOps - 一站式软件研发管理平台-腾讯云](https://coding.net/) 
4. [The One DevOps Platform | GitLab](https://about.gitlab.com/) 
5. [GitLab下载安装_一站式DevOps平台-极狐GitLab中文官方网站](https://gitlab.cn/) GitLab 中国版
6. [Gitea: Git with a cup of tea](https://gitea.com/) 
7. [Projects · Explore · GitLab (framagit.org)](https://framagit.org/) 
8. [Google Open Source](https://opensource.google/) 
9. [Compare, Download & Develop Open Source & Business Software - SourceForge](https://sourceforge.net/) 
10. [Bitbucket | Git solution for teams using Jira](https://bitbucket.org/) 
11. [云效 Codeup · 企业级代码管理平台 (aliyun.com)](https://codeup.aliyun.com/) 
12. [Codeberg.org](https://codeberg.org/) 
13. [CodeFever (pgyer.com)](https://codefever.pgyer.com/) 
14. [CodeFever Community](https://codefever.cn/) 
15. [Gogs: A painless self-hosted Git service](https://gogs.io/) 
16. [百度效率云 | Git代码托管，版本管理，项目管理，持续集成，持续交付，研发工具云端解决方案](http://xiaolvyun.baidu.com/) 

## 4.2 教程

1. [免费学习编程 - Python、JavaScript、Java、Git 等 (freecodecamp.org)](https://www.freecodecamp.org/chinese/) 
2. [慕课网-程序员的梦工厂 (imooc.com)](https://www.imooc.com/) 
3. [MDN Web Docs (mozilla.org)](https://developer.mozilla.org/zh-CN/) 
4. [菜鸟教程 - 学的不仅是技术，更是梦想！ (runoob.com)](https://www.runoob.com/) 
5. [Vue.js - The Progressive JavaScript Framework | Vue.js (vuejs.org)](https://vuejs.org/) 
6. [React 官方中文文档 – 用于构建用户界面的 JavaScript 库 (reactjs.org)](https://zh-hans.reactjs.org/) 
7. [Angular](https://angular.io/) 
8. [Angular - 中文网站](https://angular.cn/)
9. [书栈网 · BookStack_程序员IT互联网开源编程书籍免费阅读，助您【码】力十足！](https://www.bookstack.cn/) 
10. [w3school 在线教程](https://www.w3school.com.cn/index.html) 
11. [w3cschool官网 - 编程狮，随时随地学编程](https://www.w3cschool.cn/) 
12. [How2J 的 Java教程](https://how2j.cn/) 
13. [学习 Java 语言的在线教程 - CodeGym](https://codegym.cc/zh/) 
14. [易百教程™ - 专注于IT教程和实例 (yiibai.com)](https://www.yiibai.com/) 
15. [编程帮：分享优质编程教程 (biancheng.net)](http://www.biancheng.net/) 
16. [极客时间-轻松学习，高效学习-极客邦 (geekbang.org)](https://time.geekbang.org/) 
17. [比特就业课 (bitejiuyeke.com)](https://www.bitejiuyeke.com/index) 
18. [百度前端技术学园 (baidu.com)](http://ife.baidu.com/) 

## 5.3 论坛

1. [博客园 - 开发者的网上家园 (cnblogs.com)](https://www.cnblogs.com/) 
2. [链滴 - 记录生活，连接点滴 (ld246.com)](https://ld246.com/) 
3. [简书 - 创作你的创作 (jianshu.com)](https://www.jianshu.com/) 
4. [技术成就梦想51CTO-中国领先的IT技术网站](https://www.51cto.com/) 
5. [InfoQ - 促进软件开发及相关领域知识与创新的传播-极客邦](https://www.infoq.cn/) 
6. [OSCHINA - 中文开源技术交流社区](https://www.oschina.net/) 
7. [V2EX](https://www.v2ex.com/) 
8. [稀土掘金 (juejin.cn)](https://juejin.cn/) 
9. [CSDN - 专业开发者社区](https://www.csdn.net/) 
10. [SegmentFault 思否](https://segmentfault.com/) 
11. [Stack Overflow - Where Developers Learn, Share, & Build Careers](https://stackoverflow.com/) 
12. [墨滴 | 看颜值的文章社区 (mdnice.com)](https://mdnice.com/) 

## 4.4 博客

1. [Blogger.com - 轻松创建独一无二的精美博客。](https://www.blogger.com/) 
2. [Hexo](https://hexo.io/zh-cn/) 
3. [The world’s fastest framework for building websites | Hugo (gohugo.io)](https://gohugo.io/) 
4. [VuePress (vuejs.org)](https://vuepress.vuejs.org/zh/) 
5. [Jekyll • Simple, blog-aware, static sites | Transform your plain text into static websites and blogs](https://jekyllrb.com/) 
6. [Pelican – A Python Static Site Generator (getpelican.com)](https://getpelican.com/) 
7. [GitBook - Where technical teams document.](https://www.gitbook.com/) 
8. [docsify - A magical documentation site generator.](https://docsify.js.org/#/) 
9. [Gridea | 一个静态博客写作客户端](https://gridea.dev/) 
10. [The Fastest Frontend for the Headless Web | Gatsby (gatsbyjs.com)](https://www.gatsbyjs.com/) 
11. [Astro | Build faster websites](https://astro.build/) 
12. [Build optimized websites quickly, focus on your content | Docusaurus](https://www.docusaurus.io/zh-CN/) 
13. [Material for MkDocs (squidfunk.github.io)](https://squidfunk.github.io/mkdocs-material/) 
14. [MrDoc觅思文档 - 私有化部署的在线文档系统和知识库系统](https://www.mrdoc.pro/) 
15. [Typecho Official Site](http://typecho.org/) 
16. [Halo](https://halo.run/) 
17. [Solo - Java 博客系统，Java 开源博客系统 (b3log.org)](https://b3log.org/solo/) 
18. [adlered/bolo-solo: 🍍Bolo菠萝博客 专为程序员设计的精致Java博客系统 ](https://github.com/adlered/bolo-solo) 
19. [适用于博客到大型网站的 CMS (内容管理系统) | WordPress.org China 简体中文](https://cn.wordpress.org/) 
20. [ModStart - 基于Laravel的全栈极速开发框架](https://modstart.com/) 
21. [ZBlog、Z-Blog官方网站，开源免费、小巧强大的博客程序与CMS建站系统 (zblogcn.com)](https://www.zblogcn.com/) 

## 4.5 刷题

1. [力扣（LeetCode）官网 - 全球极客挚爱的技术成长平台](https://leetcode.cn/) 
2. [首页 - 洛谷 | 计算机科学教育新生态 (luogu.com.cn)](https://www.luogu.com.cn/) 
3. [牛客网-找工作神器|笔试题库|面试经验|实习招聘内推，求职就业一站解决_牛客网 (nowcoder.com)](https://www.nowcoder.com/) 
4. [LintCode 炼码](https://www.lintcode.com/) 
5. [Top Website Designers, Developers, Freelancers for Your Next Project | Topcoder](https://www.topcoder.com/) 
6. [Coderbyte | Technical Assessments & Interviews](https://coderbyte.com/) 

## 4.6 云服务

1. [腾讯云 产业智变·云启未来 - 腾讯 (tencent.com)](https://cloud.tencent.com/) 
2. [阿里云-为了无法计算的价值 (aliyun.com)](https://www.aliyun.com/) 
3. [共建智能世界云底座-华为云 (huaweicloud.com)](https://www.huaweicloud.com/) 
4. [京东云 (jdcloud.com)](https://www.jdcloud.com/) 
5. [百度智能云-智能时代基础设施 (baidu.com)](https://cloud.baidu.com/) 
6. [又拍云 - 加速在线业务 - CDN加速 - 云存储 (upyun.com)](https://www.upyun.com/) 
7. [七牛云 | 一站式场景化智能视频云 (qiniu.com)](https://www.qiniu.com/) 
8. [中国电信-天翼云,云网融合,安全可信,专享定制 (ctyun.cn)](https://www.ctyun.cn/) 
9. [移动云官网\_云主机\_云空间\_CDN_云硬盘\_云数据库 (10086.cn)](https://ecloud.10086.cn/home/) 
10. [金山云-全球高品质云服务专家 (ksyun.com)](https://www.ksyun.com/) 
11. [UCloud优刻得-首家公有云科创板上市公司](https://www.ucloud.cn/) 
12. [多吉云 | 视频云 - 云存储 - 网站加速 (dogecloud.com)](https://www.dogecloud.com/) 
13. [网宿云-可靠的企业级云服务专家 (wangsucloud.com)](https://www.wangsucloud.com/#/home) 
14. [浪潮云-无处不在的计算 (inspur.com)](https://cloud.inspur.com/) 
15. [FIT2CLOUD 飞致云 - 为数字经济时代创造好软件](https://www.fit2cloud.com/) 
16. [第一家混合云上市公司 | 青云QingCloud](https://www.qingcloud.com/) 
17. [星域云 - 全球边缘计算的创领者 (xycloud.com)](https://www.xycloud.com/) 
18. [美团云(MOS) - 云主机\_云服务器\_云计算_美团网云平台,基础设施服务,稳定提升价值 (mtyun.com)](https://www.mtyun.com/) 
19. [网易数帆-专注企业数字化未来 (163.com)](https://sf.163.com/) 
20. [博云-让企业数字化转型更高效 (bocloud.com.cn)](https://www.bocloud.com.cn/) 
21. [AWS 云服务-专业的大数据和云计算服务以及云解决方案提供商 (amazon.com)](https://aws.amazon.com/cn/) 
22. [云计算服务 | Microsoft Azure](https://azure.microsoft.com/zh-cn/) 
23. [SSD VPS Servers, Cloud Servers and Cloud Hosting - Vultr.com](https://www.vultr.com/) 
24. [Mass VPS hosting on Enterprise equipment - BandwagonHost VPS (bwh81.net)](https://bwh81.net/) 
25. [搬瓦工官网 - BandwagonHost VPS (bwg88.com)](https://www.bwg88.com/index.html) 
26. [Contabo🥇Cloud VPS & Dedicated Servers for a Price You'll Love](https://contabo.com/en/) 
27. [RackNerd - Introducing Infrastructure Stability](https://www.racknerd.com/) 
28. [Compute Servers — CLOUDCONE](https://app.cloudcone.com.cn/compute) 
29. [Cloud Computing & Linux Servers | Alternative to AWS | Linode](https://www.linode.com/) 
30. [GreenCloud - Affordable KVM and Windows VPS (greencloudvps.com)](https://greencloudvps.com/) 
31. [云计算服务  | Google Cloud](https://cloud.google.com/?hl=zh-cn) 
32. [HostKVM - Kvm VPS伺服器供應商](https://hostkvm.com/) 
33. [SSD VPS powered by NVMe storage — HostHatch](https://hosthatch.com/) 
34. [iON云服务器 - iON - by Krypt / VPLS](https://ion.krypt.asia/?language=chinese) 
35. [客戶系統 - Spartan Host Ltd](https://billing.spartanhost.net/index.php?language=chinese) 
36. [门户首页 - SaltyFishCloud](https://portal.saltyfish.io/) 
37. [Dedicated Server, Cloud, Storage & Hosting (hetzner.com)](https://www.hetzner.com/) 
38. [Oracle 甲骨文中国 | 云应用和云平台](https://www.oracle.com/cn/) 
39. [OLink Cloud](https://www.olink.cloud/) 
40. [Cloudflare 中国官网 | 智能化云服务平台 | 免费CDN安全防护 | Cloudflare](https://www.cloudflare.com/zh-cn/) 
41. [Develop. Preview. Ship. For the best frontend teams – Vercel](https://vercel.com/) 
42. [Develop and deploy websites and apps in record time | Netlify](https://netlify.app/) 
43. [4EVERLAND - A Cloud Computing Platform of WEB 3.0](https://4everland.org/) 
44. [Surge](https://surge.sh/) 

购买服务器可以看看这位老哥的博客 [我不是咕咕鸽——VPS折腾不完全记录 (laoda.de)](https://blog.laoda.de/) 

## 4.7 在线编程（前端）

1. [CodePen: Online Code Editor and Front End Web Developer Community](https://codepen.io/) 
2. [JSFiddle - Code Playground](https://jsfiddle.net/) 
3. [JS Bin - Collaborative JavaScript Debugging](http://jsbin.com/?html,output) 
4. [RunKit is Node prototyping](https://runkit.com/home) 
5. [regex101: build, test, and debug regex](https://regex101.com/) 
6. [CodeSandbox: Online Code Editor and IDE for Rapid Web Development](https://codesandbox.io/) 
7. [StackBlitz | Instant Dev Environments | Click. Code. Done.](https://stackblitz.com/) 
8. [码上掘金 (juejin.cn)](https://code.juejin.cn/) 

# 笔记软件类

## 5.1 Markdown

1. [Typora — a markdown editor, markdown reader.](https://www.typora.io/) 
2. [Milkdown](https://milkdown.dev/zh-hans) 
3. [marktext/marktext: 📝A simple and elegant markdown editor, available for Linux, macOS and Windows. (github.com)](https://github.com/marktext/marktext) 
4. [Online Markdown Editor - Dillinger, the Last Markdown Editor ever.](https://dillinger.io/) 
5. [小书匠 (xiaoshujiang.com)](http://soft.xiaoshujiang.com/) 
6. [Cmd Markdown 编辑阅读器 - 作业部落出品 (zybuluo.com)](https://www.zybuluo.com/cmd/) 
7. [妙言 (miaoyan.app)](https://miaoyan.app/) 目前仅支持 MacOS
8. [Ulysses](https://ulysses.app/) 目前仅支持 MacOS
9. [熊掌记 - iPhone、iPad 和 Mac 上的 Markdown 笔记应用 (bear.app)](https://bear.app/cn/) 目前仅支持 MacOS
10. [MWeb - 专业的Markdown写作、记笔记、静态博客生成软件 - MWeb](https://zh.mweb.im/) 目前仅支持 MacOS
11. [Joplin (joplinapp.org)](https://joplinapp.org/) 
12. [Notable - The Markdown-based note-taking app that doesn't suck](https://notable.app/) 
13. [A Markdown Editor for the 21st Century | Zettlr](https://www.zettlr.com/) 
14. [Haroopad - The Next Document processor based on Markdown (haroopress.com)](http://pad.haroopress.com/) 
15. [Arya - 在线 Markdown 编辑器 (lovejade.cn)](https://markdown.lovejade.cn/) 
16. [Simplenote](https://simplenote.com/) 
17. [VNote - 一个舒适的笔记平台](http://app.vnote.fun/zh_cn/) 
18. [Home – iA](https://ia.net/) 

## 5.2 在线文档类

1. [腾讯文档 (qq.com)](https://docs.qq.com/) 
2. [金山文档 · 一起办公才高效 (kdocs.cn)](https://www.kdocs.cn/) 
3. [石墨文档官网-在线协同办公系统平台,支持云端多人在线协作文档,表格,幻灯片 (shimo.im)](https://shimo.im/) 
4. [飞书文档-可多人实时编辑的在线文档（文档、表格、思维笔记）高效协同办公软件 (feishu.cn)](https://docs.feishu.cn/) 
5. [讯飞文档—多人协作在线文档编辑-实现语音、办公Word文档表格共享 (iflydocs.com)](https://iflydocs.com/) 
6. [Thoughts | 面向中小企业的知识管理工具 (teambition.com)](https://thoughts.teambition.com/site) 
7. [语雀 - 用语雀，构建你的数字花园 (yuque.com)](https://www.yuque.com/) 
8. [钉钉文档-专注提供安全实时高效的企业级文档（文档、表格、脑图）服务 (dingtalk.com)](https://docs.dingtalk.com/) 

## 5.3 导图类

1. [Xmind思维导图 | Xmind中文官方网站](https://xmind.cn/) 
2. [Xmind - Mind Mapping App](https://xmind.app/) 
3. [绘制精美的流程图、思维导图、信息图等 - 亿图官网 (edrawsoft.cn)](https://www.edrawsoft.cn/) 
4. [MindMaster 多平台思维导图软件，让您的创意破茧而出 (edrawsoft.cn)](https://www.edrawsoft.cn/mindmaster/ad.html) 
5. [百度脑图 - 便捷的思维工具 (baidu.com)](https://naotu.baidu.com/) 
6. [幕布 - 极简大纲笔记 ｜ 一键生成思维导图 (mubu.com)](https://mubu.com/home) 
7. [ProcessOn思维导图、流程图-思维导图模板\_思维导图软件免费下载_在线作图协作工具](https://www.processon.com/) 
8. [未命名绘图 - diagrams.net (draw.io)](https://www.draw.io/index.html) 
9. [MindLine思维导图](http://www.mindline.cn/) 
10. [免费思维导图模板大全\_思维导图主题模板下载_知犀官网 (zhixi.com)](https://www.zhixi.com/) 
11. [GitMind · 思乎 - 在线思维导图脑图架构图制作软件工具](https://gitmind.cn/) 
12. [ZhiMap - 在线思维导图、电脑与手机微信里都能作图](https://zhimap.com/) 
13. [MindManager 思维导图软件 | MindManager](https://www.mindmanager.com/cn/) 

## 5.4 知识库类

1. [思源笔记 - 本地优先的个人知识管理系统，支持 Markdown 排版、块级引用和双向链接 (b3log.org)](https://b3log.org/siyuan/) 
2. [Obsidian](https://obsidian.md/) 
3. [Obsidian 中文论坛 - Obsidian 知识管理 笔记](https://forum-zh.obsidian.md/) 
4. [RoamEdit官网-双向链接大纲笔记工具](https://roamedit.com/) 
5. [RoamEdit官方论坛](https://club.roamedit.com/club/) 
6. [Logseq: A privacy-first, open-source knowledge base](https://logseq.com/) 
7. [Logseq 中文社区 - Logseq - 开源，隐私第一的知识管理平台](https://cn.logseq.com/) 
8. [Logseq - Logseq forum](https://discuss.logseq.com/) 
9. [我来 wolai - 不仅仅是未来的云端协作平台与个人笔记](https://www.wolai.com/product) 
10. [FlowUs息流官网-新一代知识管理与协同平台,在线文档笔记知识库,项目管理协作](https://flowus.cn/product) 
11. [Notion – The all-in-one workspace for your notes, tasks, wikis, and databases.](https://www.notion.so/) 
12. [Notion.Work](https://notion.work/) 
13. [Notion 中文社区导航](https://www.notion.so/Notion-e18268991cd14de89b1cad0de60baa91) 
14. [NotionChina](https://notionchina.co/) 
15. [ClickUp™ | One app to replace them all](https://www.clickup.com/) 
16. [RemNote](https://www.remnote.com/) 
17. [A simpler way to organize your work - Workflowy](https://workflowy.com/) 
18. [Airtable | Create apps that perfectly fit your team's needs](https://www.airtable.com/) 
19. [SeaTable - 新一代在线协同表格和数字化平台](https://www.seatable.cn/) 
20. [Effie官网 ｜ Effie - 把思想变成价值](https://www.effie.co/) 
21. [Drafts | Where Text Starts (getdrafts.com)](https://getdrafts.com/) 
22. [葫芦笔记•多人超级大脑：微信聊天整理神器，下一代多人协作办公 (hulunote.com)](https://www.hulunote.com/app#/main)  

## 5.5 白板类

1. [Heptabase](https://heptabase.com/) 
2. [Milanote - the tool for organizing creative projects](https://milanote.com/) 
3. [Excalidraw | Hand-drawn look & feel • Collaborative • Secure](https://excalidraw.com/) 
4. [BoardMix博思白板，多人实时协作的流程图，思维导图免费工具](https://boardmix.cn/) 
5. [The Visual Collaboration Platform for Every Team | Miro](https://miro.com/index/) 
6. [Microsoft Whiteboard微软白板虚拟画布-Whiteboard下载-Microsoft 365](https://www.microsoft.com/zh-cn/microsoft-365/microsoft-whiteboard/digital-whiteboard-app) 
7. [Muse — dive into big ideas (museapp.com)](https://museapp.com/) 
8. [Witeboard | Shareable Online Whiteboard](https://witeboard.com/) 
9. [Collaborative, Online Whiteboard for Teams | FigJam (figma.com)](https://www.figma.com/figjam/) 
10. [Teamind - 创造无限可能的在线白板](https://www.teamind.co/) 
11. [来画白板-实时协作的在线白板工具 (laihua.com)](https://www.laihua.com/whimark) 
12. [Fabrie - 设计师的在线设计协作平台 ｜ 融合表格的在线白板工作台](https://www.fabrie.cn/home) 
13. [希沃白板5 为互动教学而生 | 课件制作神器 (seewo.com)](http://easinote.seewo.com/) 
14. [氢图 - 视觉笔记，可视化记录与思考 (qingtu.co)](https://qingtu.co/) 
15. [在线做图|在线白板|在线画图\_VisionOn_新一代轻量在线图形工具](https://pub.visionon.cn/) 
16. [Colube](https://colube.cn/) 

## 5.6 卡片类

1. [Writeathon](https://www.writeathon.cn/) 
2. [氢刻 - 全平台同步的卡片记忆工具 (qingk.com)](https://qingk.com/) 
3. [flomo · 浮墨笔记 (flomoapp.com)](https://flomoapp.com/) 
4. [Scapple | Literature & Latte (literatureandlatte.com)](https://www.literatureandlatte.com/scapple/overview) 
5. [Gingko Writer](https://gingkowriter.com/) 
6. [元思笔记 (metaslip.com)](http://www.metaslip.com/) 

## 5.7 清单类

1. [滴答清单:一个帮你高效完成任务和规划时间的应用 (dida365.com)](https://www.dida365.com/) 
2. [Todoist | 管理您工作和生活的To Do List](https://todoist.com/zh-CN) 
3. [Todo清单官网 - 强大的待办事项软件 & 跨平台无缝同步 & 番茄工作法 & 时间管理大师 (evestudio.cn)](https://todo.evestudio.cn/) 
4. [欢迎使用 To Do (microsoft.com)](https://todo.microsoft.com/tasks/) 
5. [The all-new Things. Your to-do list for Mac & iOS (culturedcode.com)](https://culturedcode.com/things/) 
6. [Organize your life and manage your team's work with Any.do](https://www.any.do/) 
7. [Sorted³ – Hyper-schedule your entire day in one place (sortedapp.com)](https://www.sortedapp.com/) 
8. [闪点清单 官网 (flicker.cool)](https://flicker.cool/) 

## 5.8 传统笔记类

1. [印象笔记 | 工作必备效率应用 (yinxiang.com)](https://www.yinxiang.com/) 
2. [有道云笔记｜亿万用户的选择 (youdao.com)](https://note.youdao.com/)
3. [为知笔记 | 云笔记,个人知识管理,团队协作,资料库,知识管理,记事本,加密笔记,替代印象笔记,会议记录,日志,认知卸载 (wiz.cn)](https://www.wiz.cn/zh-cn) 
4. [享做笔记官方网站|学习工作必备神级应用 (xiangzuobiji.com)](http://www.xiangzuobiji.com/#/index) 
5. [Microsoft Word文档官网-微软Office文字处理软件Word下载 | Word](https://www.microsoft.com/zh-cn/microsoft-365/word) 
6. [Microsoft Excel官网-微软Office办公软件Excel电子表格下载 | Excel](https://www.microsoft.com/zh-cn/microsoft-365/excel) 
7. [Office PowerPoint官网-ppt演示文稿幻灯片软件下载 | PowerPoint (microsoft.com)](https://www.microsoft.com/zh-cn/microsoft-365/powerpoint) 
8. [Microsoft OneNote 数字笔记记录应用 | Microsoft 365](https://www.microsoft.com/zh-cn/microsoft-365/onenote/digital-note-taking-app) 

## 5.9 收藏夹类

1. [Cubox 个人碎片知识库](https://cubox.pro/) 
2. [Pinbox - 跨平台收藏工具 (withpinbox.com)](https://withpinbox.com/) 
3. [Pocket: 主页 (getpocket.com)](https://getpocket.com/zh-cn/) 
4. [Save the web, freely | wallabag: a self hostable application for saving web pages](https://wallabag.org/en) 
5. [Raindrop.io — All-in-one bookmark manager](https://raindrop.io/) 
6. [WebCull - Ad-Free and Privacy-Focused Bookmark Manager](https://webcull.com/) 


# 获取网站 Icon 方法

## 1、网站源码搜索

`Ctrl+U` 进入网页的源码模式，`Ctrl+F` 搜索，关键词：svg / png / ico。首推 svg 格式。

## 2、iconfont 下载

进入 https://www.iconfont.cn/，搜索网站 Icon。首推 svg 格式。中文搜索不到，就用英文。iconfont 应该下架了部分网站 Icon 图标。或者在 https://www.iconfont.cn/collections/index?keyword=logo&page= 图标库里搜索。

类似网站

- [Search results for Logo - Flaticon](https://www.flaticon.com/search?word=logo)
- [Simple Icons](https://simpleicons.org/zh-CN/)

## 3、插件获取

- [网站图标探测器 - Chrome 应用商店 (google.com)](https://chrome.google.com/webstore/detail/favicon-detector/jlfeffjhgmgblofcgpbgpkkhfniipejm) 
- [网站图标探测器 - Microsoft Edge Addons](https://microsoftedge.microsoft.com/addons/detail/网站图标探测器/kmlcolmkcjbpagopgiojkflkejfnnjbm) 
- [Get Favicon - Chrome 应用商店 (google.com)](https://chrome.google.com/webstore/detail/get-favicon/gpipahagclehninhhjkhbkliinfofnhe) 

根据自己使用的浏览器，选择安装。在需要获取 Icon 的网站，点击扩展图标，稍等，会弹出 Icon 链接。「Get Favicon」的获取速度更快，「网站图标探测器」的获取格式更多。

## 4、代码获取

浏览器添加书签，输入以下代码。

```js
javascript:(function(){var a=0,b=[],c=0,b=document.getElementsByTagName("link");if(0<b.length){for(a=0;a<b.length;a++)"undefined"!==typeof b[a].rel&&-1<b[a].rel.indexOf("icon")&&(c=1,window.open(b[a].href));0===c&&window.open("http://"+window.location.host+"/favicon.ico")}else window.open("http://"+window.location.host+"/favicon.ico")})();
```

使用方法：在需要获取 Icon 的网站，点击该书签，新标签页显示网站 Icon。

> 来源：[总结:如何获取网站的 favicon (yuque.com)](https://www.yuque.com/achuan-2/blog/rp2myq#b3c6b26a) 

## 5、网站获取

访问 [Favicon Grabber — Online service with public API to grab favicons from any domain](https://favicongrabber.com/) ，输入需要获取 Icon 的网址，获取 Icon 链接，稍等，便可以下载网站 Icon。

## 6、Infinity 新标签页 (Pro) 获取

安装该插件，获取 Icon 方法如下：

 点击右上角 $\infty$ 标志 → 弹出侧边栏，搜索需要获取 Icon 的网站 → 添加至新标签页 → `F12` 打开开发者工具，定位到网站 Icon 上 → 找到 Icon 链接，新标签页打开，保存。

## 7、提取手机应用图标

下载 [一个木函 - 多功能效率工具箱 (woobx.cn)](https://www.woobx.cn/) ，应用管理界面，点击应用，提取图标。

## 8、手机应用商店下载

访问 **4.8 应用商店**任一链接，搜索应用，保存图片。可以使用 [Picviewer CE+ ](https://greasyfork.org/zh-CN/scripts/24204-picviewer-ce) 油猴脚本保存。

个人觉得 App Store 的图片要清晰点。

[HQ ICON (yukonga.top)](https://icon.yukonga.top/)

## 图片格式

Icon 选择优先级：svg > png > ico

- [免费PNG转SVG在线转换器 (converter.app) ](https://converter.app/cn/png-svg/) 
- [ICO转SVG - 免费在线将ICO文件转换成SVG (cdkm.com)](https://cdkm.com/cn/ico-to-svg) 
- [在线转换 svg 文件格式，将图片免费转换成 svg 格式 (onlineconvertfree.com)](https://onlineconvertfree.com/zh/convert/svg/) 

这两个网站转换效果比较好。

[Find Logo Vector - Download Free Vector Logos](https://findlogovector.com/) 

 
